from openmmforcefields.generators import EspalomaTemplateGenerator
from openmm.app.forcefield import ForceField
from openff.toolkit.topology import Molecule
from openmm.app import StateDataReporter
from rdkit.Chem.Draw import rdMolDraw2D
from simtk.openmm import XmlSerializer
from rdkit.Chem.Draw import rdDepictor
from openmm import LangevinIntegrator
from openff.toolkit import Molecule
from openmm.openmm import Platform
from openmm.app import DCDReporter
from openmm.app import Simulation
from openmm.app import Modeller
from IPython.display import SVG
from simtk.openmm import openmm
from rdkit.Chem import AllChem
from openmm.app import PDBFile
from simtk.openmm import app
from rdkit.Chem import Draw
import openmm.unit as unit
from openeye import oechem
from simtk import openmm
from sys import stdout
from simtk import unit
from rdkit import Chem
from typing import Any
import espaloma as esp
from rdkit import Chem
import numpy as np
import subprocess
import argparse
import warnings
import mdtraj
import openmm
import shutil
import os

from chcl3 import *

# Get parsed command-line arguments
args = parse_arguments()
# Parse the ligand range to process
ligand_range = parse_range(args.range)
input_sdf_path = args.sdf
# List of excluded ligands to skip during processing
excluded_ligands = [12, 28, 31, 36, 37, 54, 57, 58, 60, 61, 64, 76, 78, 80, 86, 90,
                    94, 95, 96, 97, 98, 100, 102, 104, 108, 111, 112, 113, 115, 118,
                    121, 122, 124, 126, 127, 128, 129, 132, 133, 134]
# Get the current directory as the root directory for reference
root_directory = os.getcwd()
# Create a log file based on the specified ligand range
log_file_name = f'production_{args.range}.log'
# Open the log file for recording progress and results
with open(log_file_name, 'w') as log_file:
    # Log the initial parameters
    log(f"Starting process with the following parameters:", log_file)
    log(f"Range: {args.range}", log_file)
    log(f"SDF File: {args.sdf}", log_file)
    log(f"Prepare folders: {'Yes' if args.prepare else 'No'}", log_file)
    # Optionally prepare folders by splitting the SDF file into individual ligand directories
    if args.prepare:
        log("Preparing folders from SDF file...", log_file)
        total_ligands = split_sdf_file(input_sdf_path=input_sdf_path)
        log(f'Total ligands processed: {total_ligands}', log_file)
    else:
        log('Skipping folder preparation.', log_file)
    # Function to sort ligand directories numerically based on the ligand number
    def sort_ligand_dirs(dirs):
        return sorted(dirs, key=lambda x: int(x.replace('ligand', '')))
    # Get the list of directories for ligands and sort them numerically
    ligand_dirs = sort_ligand_dirs(
        [d for d in os.listdir(root_directory)
         if os.path.isdir(os.path.join(root_directory, d)) and d.startswith('ligand')])
    # Log the number of ligand directories found
    log(f"Total ligand directories found: {len(ligand_dirs)}", log_file)
    # Process each ligand directory in the list
    for ligand_dir in ligand_dirs:
        ligand_number = int(ligand_dir.replace('ligand', ''))
        # Skip ligands that are out of the specified range or in the excluded list
        if ligand_number not in ligand_range or ligand_number in excluded_ligands:
            log(f"Skipping ligand {ligand_number} (out of range or excluded)", log_file)
            continue
        # Set the path to the ligand directory
        ligand_path = os.path.join(root_directory, ligand_dir)
        try:
            log(f'Processing ligand {ligand_number} in directory {ligand_dir}', log_file)
            # Change to the ligand directory for processing
            os.chdir(ligand_path)
            # Perform ligand parameterization and energy minimization
            sdf_to_pdb(ligand_SDF=f"{ligand_dir}.sdf", 
                espaloma_model="0.3.2",
                temperature=300, 
                friction=1, 
                timestep=0.002, 
                openff_ligand_PDB="ligand_openff.pdb", 
                openmm_ligand_PDB="ligand.pdb", 
                openff_ligand_SDF="ligand_openff.sdf")
            # Run Antechamber to generate force field files for the ligand
            run_antechamber(input_pdb="ligand.pdb", 
                prepin_file="ligand.prepin", 
                frcmod_file="ligand.frcmod")
            # Create .lib file using tleap
            create_lib_file(prepin_file="ligand.prepin", 
                frcmod_file="ligand.frcmod", 
                input_pdb_file="ligand.pdb", 
                lib_file="ligand.lib", 
                tleap_file="lib_script.tleap")
            # Solvate the ligand in a chloroform box and generate the AMBER topology
            solvate_chloroform(prepin_file="ligand.prepin", 
                frcmod_file="ligand.frcmod", 
                lib_file="ligand.lib", 
                input_pdb="ligand.pdb", 
                prmtop_file="system.prmtop", 
                inpcrd_file="system.inpcrd", 
                solvated_pdb_file="system.pdb", 
                tleap_file="solvate.tleap", 
                box_size=10.0)
            # Serialize the system as an XML file
            get_xml(prmtop_file="system.prmtop", 
                pdb_file="system.pdb", 
                xml_file="system.xml")
            # Run MD simulation with the solvated system
            run_simulation_with_solvent(xml_file="system.xml", 
                pdb_file="system.pdb", 
                steps=50000, 
                dcd_output="system_before_params.dcd", 
                platform="CUDA", 
                temperature=300, 
                friction=1, 
                timestep=0.002, 
		save_frequency=5000,
                output_pdb="system_before_params.pdb")
            # Extract the ligand from the solvated system
            extract_ligand(input_pdb="system.pdb", 
                residue_name="UNK", 
                ligand_pdb_file="ligand_amber.pdb")
            # Convert the ligand PDB to SDF format
            pdb_to_sdf(input_pdb="ligand_amber.pdb", 
                output_sdf="ligand_oechem.sdf")
            # Modify the SDF file to prepare it for parameterization
            rdkitize_sdf(input_sdf="ligand_oechem.sdf", 
                output_sdf="ligand.sdf")
            # Parameterize the ligand using Espaloma and save as XML
            parameterize_ligand(ligand_sdf="ligand.sdf", 
                xml_file="ligand.xml", 
                espaloma_version="0.3.2")
            # Get the number of atoms
            threshold = get_threshold(system_file="system.xml", 
                ligand_file="ligand.xml")
            # Generate a clean template XML file
            tags_to_remove = [('<Particles>', '</Particles>'), 
                ('<Constraints>', '</Constraints>'), 
                ('<Bonds>', '</Bonds>'), 
                ('<Angles>', '</Angles>'), 
                ('<Torsions>', '</Torsions>'), 
                ('<Exceptions>', '</Exceptions>')]
            generate_template_xml(input_file='system.xml', 
                output_file='template.xml', 
                tags_to_remove=tags_to_remove)
            # Update bond, angle, torsion, and exception forces 
            add_bond_forces_template(system_file="system.xml", 
                ligand_file="ligand.xml", 
                template_file="template.xml", 
                threshold=threshold)
            add_angle_forces_template(system_file="system.xml", 
                ligand_file="ligand.xml", 
                template_file="template.xml", 
                threshold=threshold)
            add_torsion_forces_template(system_file="system.xml", 
                ligand_file="ligand.xml", 
                template_file="template.xml", 
                threshold=threshold)
            add_exception_forces_template(system_file="system.xml", 
                ligand_file="ligand.xml", 
                template_file="template.xml", 
                threshold=threshold)
            # Update particle masses 
            process_mass_template(system_file="system.xml", 
                ligand_file="ligand.xml", 
                template_file="template.xml", 
                threshold=threshold)
            # Update Lennard-Jones (LJ) parameters
            process_lj_template(system_file="system.xml", 
                ligand_file="ligand.xml", 
                template_file="template.xml", 
                threshold=threshold)
            # Backup the original system XML and rename the template XML file
            copy_file(source_file="system.xml", file_name="system_before_params.xml")
            delete_file(file="system.xml")
            copy_file(source_file="template.xml", file_name="system.xml")
            # Run MD simulations after parameter modifications
            run_simulation_with_solvent(xml_file="system.xml", 
                pdb_file="system.pdb", 
                steps=50000, 
                dcd_output="system_after_params.dcd", 
                platform="CUDA", 
                temperature=300, 
                friction=1, 
                timestep=0.002, 
                save_frequency=5000,
                output_pdb="system_after_params.pdb")
            # Move intermediate files to a separate directory
            move_files(files=['system.xml', 'system.pdb', f"{ligand_dir}.sdf"])
            # Run simulation 
            run_simulation_with_solvent( xml_file="system.xml", 
                pdb_file="system.pdb", 
                steps=10000, 
                dcd_output="trajectory_ligand.dcd", 
                platform="CUDA", 
                temperature=300, 
                friction=1, 
                timestep=0.002, 
                save_frequency=5000,
                output_pdb="solvated_ligand_final.pdb")
            # Strip the solvent and ions from the trajectory and final PDB file
            strip_trajectory(trajectory_file='trajectory_ligand.dcd',
                topology_file='solvated_ligand_final.pdb',
                ligand_resname='UNK',
                output_file='stripped_trajectory.pdb',
                log_file=log_file)
            strip_trajectory(trajectory_file='solvated_ligand_final.pdb',
                topology_file='solvated_ligand_final.pdb',
                ligand_resname='UNK',
                output_file='stripped_ligand.pdb',
                log_file=log_file)
            # Log successful ligand processing
            log(f"Ligand {ligand_number} processing complete: PASS", log_file)
        except Exception as e:
            # Log failures and exception messages
            log(f"Ligand {ligand_number} processing failed: FAIL - {str(e)}", log_file)
        finally:
            # Ensure the script returns to the root directory before the next iteration
            os.chdir(root_directory)
    # Summary log at the end of the process
    log(f'Selected ligands processed. Check {log_file_name} for detailed log.', log_file)
print(f'Process complete. See {log_file_name} for details.')

from openmmforcefields.generators import EspalomaTemplateGenerator
from openmm.app.forcefield import ForceField
from openff.toolkit.topology import Molecule
from openmm.app import StateDataReporter
from rdkit.Chem.Draw import rdMolDraw2D
from simtk.openmm import XmlSerializer
from rdkit.Chem.Draw import rdDepictor
from openmm import LangevinIntegrator
from openff.toolkit import Molecule
from openmm.openmm import Platform
from openmm.app import DCDReporter
from openmm.app import Simulation
from openmm.app import Modeller
from IPython.display import SVG
from simtk.openmm import openmm
from rdkit.Chem import AllChem
from openmm.app import PDBFile
from simtk.openmm import app
from rdkit.Chem import Draw
import openmm.unit as unit
from openeye import oechem
from simtk import openmm
from sys import stdout
from simtk import unit
from rdkit import Chem
from typing import Any
import espaloma as esp
from rdkit import Chem
import numpy as np
import subprocess
import argparse
import warnings
import mdtraj
import openmm
import shutil
import os

warnings.filterwarnings("ignore", category=UserWarning, module='dgl')

def log(message, log_file=None):
    """
    Log messages to both console and the log file.

    Parameters:
    ----------
    message : str
        The message to log.
    log_file : file object, optional
        The log file to write the message to.
    """
    print(message)
    if log_file:
        log_file.write(message + "\n")

def parse_arguments():
    """
    Parse command-line arguments using argparse.

    Returns:
    --------
    args : argparse.Namespace
        Parsed arguments.
    """
    parser = argparse.ArgumentParser(description="Proceses a range of ligand indices for an SDF file.")
    parser.add_argument("-p", "--prepare", action="store_true", help="Flag to indicate if folders should be prepared from the SDF file.")
    parser.add_argument("-s", "--sdf", type=str, required=True, help="Path to the input SDF file containing multiple ligands.")
    parser.add_argument("-r", "--range", type=str, required=True, help="Range of ligand indices to process (e.g., '1-10').")
    args = parser.parse_args()
    return args

def parse_range(range_str):
    """
    Parse a range string in the form 'start-end' and return a list of integers.

    Parameters:
    -----------
    range_str : str
        The range string to parse, e.g., '1-10'.

    Returns:
    --------
    list
        A list of integers in the specified range.

    Example:
    --------
    >>> parse_range('1-5')
    [1, 2, 3, 4, 5]
    """
    start, end = map(int, range_str.split('-'))
    return list(range(start, end + 1))

def split_sdf_file(input_sdf_path):
    """
    Splits the molecules in an SDF file into individual SDF files, each placed in a separate directory 
    within the current working directory. After processing, the original SDF file is deleted.

    Parameters:
    -----------
    input_sdf_path : str
        The file path to the input SDF file containing multiple molecules.

    Returns:
    --------
    int
        The total number of ligands processed and saved.

    Example:
    --------
    >>> total_ligands = split_sdf_file('input.sdf')
    >>> print(f'Total ligands processed: {total_ligands}')
    """

    # Load the SDF file
    suppl = Chem.SDMolSupplier(input_sdf_path)
    # Initialize a counter for the ligands
    ligand_counter = 0
    # Get the current working directory
    output_directory = os.getcwd()
    # Iterate through the molecules in the SDF file
    for mol in suppl:
        if mol is not None:
            ligand_counter += 1
            # Create a directory for each ligand in the current working directory
            ligand_dir = os.path.join(output_directory, f'ligand{ligand_counter}')
            os.makedirs(ligand_dir, exist_ok=True)
            # Save the ligand as an SDF file temporarily in the current directory
            temp_file = f'ligand{ligand_counter}.sdf'
            writer = Chem.SDWriter(temp_file)
            writer.write(mol)
            writer.close()
            # Move the SDF file to the respective directory
            shutil.move(temp_file, os.path.join(ligand_dir, temp_file))
    return ligand_counter

def sdf_to_pdb(ligand_SDF, espaloma_model, temperature, friction, timestep, openff_ligand_PDB, openmm_ligand_PDB,openff_ligand_SDF):
    """
    Parameterize a ligand molecule using the Espaloma model, perform energy minimization, visualize the molecule,
    and save the minimized structure.

    Parameters:
    ----------
    ligand_SDF : str
        Path to the ligand SDF file to be parameterized and minimized.
    espaloma_model : str
        The version of the Espaloma model to use for parameterization. Default is "0.3.2".
    temperature : float
        The temperature (in Kelvin) for the Langevin integrator. Default is 300 K.
    friction : float
        The friction coefficient (in inverse picoseconds) for the Langevin integrator. Default is 1 ps^-1.
    timestep : float
        The timestep (in picoseconds) for the Langevin integrator. Default is 0.002 ps.
    openff_ligand_PDB : str
        File path to save the minimized ligand as a PDB file using OpenFF tools.
    openmm_ligand_PDB : str
        File path to save the minimized ligand as a PDB file using OpenMM tools.
    openff_ligand_SDF : str
        File path to save the ligand, including all conformers, as an SDF file using OpenFF tools.

    Returns:
    -------
    None
        The function saves the minimized structures to the specified file paths.
    """

    mol = Molecule.from_file(ligand_SDF)
    # Convert the ligand into an Espaloma graph representation, which is suitable for parameterization
    mol_graph = esp.Graph(mol)
    # Load the Espaloma model, which is a neural network trained to predict force field parameters
    espaloma_model = esp.get_model(espaloma_model)
    # Apply the Espaloma model to the molecular graph to predict and set the necessary force field parameters
    espaloma_model(mol_graph.heterograph)
    # Convert the Espaloma graph (with assigned parameters) into an OpenMM system, which includes the force field parameters like bonds, angles, and charges
    openmm_system: openmm.System = esp.graphs.deploy.openmm_system_from_graph(mol_graph)
    # Print the number of partial charges that were generated and assigned to the molecule
    # Generate one conformer for the ligand, which is a specific 3D arrangement of its atoms
    mol.generate_conformers(n_conformers=1)
    # Display the generated conformer, showing its 3D structure
    #display(mol.conformers[0])
    # Construct and configure a Langevin integrator with a temperature, a friction constant, and a timestep for the simulation
    integrator = openmm.LangevinIntegrator(temperature * unit.kelvin, 
                                           friction / unit.picosecond, 
                                           timestep * unit.picoseconds)
    # Convert the topology of the ligand into OpenMM format
    top = mol.to_topology().to_openmm()
    # Create a simulation object by combining the topology, system (with parameters from Espaloma), and the Langevin integrator
    simulation = openmm.app.Simulation(top, openmm_system, integrator)
    # Set the initial positions for the simulation using the conformer's coordinates
    simulation.context.setPositions(mol.conformers[0].to_openmm())
    # Minimize the energy of the ligand to find a more stable 3D structure
    simulation.minimizeEnergy()
    # Get the minimized state, which includes the new positions of the atoms, the energy of the system, and the forces acting on the atoms
    minimized_state = simulation.context.getState(getPositions=True, getEnergy=True, getForces=True)
    # Calculate the maximum force acting on any atom in the system after minimization
    max_force = max(np.sqrt(v.x * v.x + v.y * v.y + v.z * v.z) for v in minimized_state.getForces())
    # Print the minimized potential energy, the maximum force, and the unit of the force
    # Get the current number of conformers associated with the molecule
    new_conformer_i = mol.n_conformers
    print(f'Adding minimized conformer at position {new_conformer_i}')
    # Add the minimized conformer (new positions) to the list of conformers for the molecule
    mol.add_conformer(minimized_state.getPositions(True))
    # Display the newly added minimized conformer
    #display(mol.conformers[new_conformer_i])
    print(mol)
    # Save the ligand, including the minimized conformer, to a PDB file using OpenFF tools
    mol.to_topology().to_file(openff_ligand_PDB, minimized_state.getPositions(True))
    # Save the minimized conformer to a PDB file using OpenMM tools, maintaining the atom IDs
    with open(openmm_ligand_PDB, 'w') as f:
        PDBFile.writeFile(top, minimized_state.getPositions(True), f, keepIds=True)
    # Save the ligand, including all conformers, to an SDF file using OpenFF tools
    mol.to_file(str(openff_ligand_SDF), 'SDF')
    # Save each conformer of the ligand as a separate SDF file using RDKit
    for i in range(mol.n_conformers):
        with Chem.SDWriter(str(f'ligand_openff_conf{i}.sdf')) as w:
            rd_mol = mol.to_rdkit()  # Convert the molecule to RDKit format
            w.write(rd_mol, i)  # Write the ith conformer to an SDF file

def run_antechamber(input_pdb, prepin_file, frcmod_file):
    """
    Runs Antechamber to generate prepin and frcmod files for the ligand, and removes intermediate files.
    
    Arguments:
    input_pdb    -- Path to the input PDB file (e.g., "ligand.pdb")
    prepin_file  -- Path to the output .prepin file to be generated (e.g., "ligand.prepin")
    frcmod_file  -- Path to the output .frcmod file to be generated (e.g., "ligand.frcmod")
    
    This function generates the prepin and frcmod files using Antechamber and Parmchk2, and then removes
    the intermediate files created during the process.
    """
    # Run Antechamber to generate the prepin file
    antechamber_command = f"antechamber -i {input_pdb} -fi pdb -o {prepin_file} -fo prepi -c gas -s 2"
    os.system(antechamber_command)
    # Run parmchk2 to generate the frcmod file
    parmchk_command = f"parmchk2 -i {prepin_file} -f prepi -o {frcmod_file}"
    os.system(parmchk_command)
    print(f"Antechamber completed. Generated: {prepin_file}, {frcmod_file}")
    # Clean up unwanted Antechamber intermediate files
    cleanup_command = "rm -rf *ANTECHAMBER* *ATOMTYPE* *NEWPDB* PREP.INF"
    os.system(cleanup_command)
    print("Cleanup completed. Removed intermediate Antechamber files.")

def create_lib_file(prepin_file, frcmod_file, input_pdb_file, lib_file, tleap_file):
    """
    Creates the tleap script to generate the lib file and runs the tleap command.
    
    Arguments:
    prepin_file     -- Path to the input .prepin file (e.g., "ligand.prepin")
    frcmod_file     -- Path to the input .frcmod file (e.g., "ligand.frcmod")
    input_pdb_file  -- Path to the input PDB file (e.g., "ligand.pdb")
    lib_file        -- Path to the output .lib file to be generated (e.g., "ligand.lib")
    tleap_file      -- Path to the tleap script to be created and executed (e.g., "lib_script.tleap")
    
    This function writes a tleap script that:
    - Loads the .prepin, .frcmod, and .pdb files of the ligand.
    - Generates the .lib file using tleap.
    
    After creating the script, the function automatically runs it using the tleap command.
    """
    # Create the tleap script content
    script_content = f"""
source leaprc.protein.ff14SB
source leaprc.gaff
loadamberprep {prepin_file}
loadamberparams {frcmod_file}
mol = loadpdb {input_pdb_file}
saveoff mol {lib_file}
quit
"""
    # Write the tleap script to the specified file
    with open(tleap_file, "w") as script_file:
        script_file.write(script_content)
    print(f"Created tleap script: {tleap_file}")

    # Run the tleap command to execute the script
    tleap_command = f"tleap -f {tleap_file}"
    os.system(tleap_command)
    print(f"Ran tleap using script: {tleap_file}")

def solvate_chloroform(prepin_file, frcmod_file, lib_file, 
                       input_pdb, prmtop_file, inpcrd_file, 
                       solvated_pdb_file, tleap_file, box_size):
    """
    Creates and runs the tleap script to solvate a ligand in chloroform (CHCL3BOX), using user-provided file names
    and customizable solvent box size.
    
    Arguments:
    prepin_file        -- Path to the input .prepin file for the ligand (e.g., "ligand.prepin")
    frcmod_file        -- Path to the input .frcmod file for the ligand (e.g., "ligand.frcmod")
    lib_file           -- Path to the input .lib file for the ligand (e.g., "ligand.lib")
    input_pdb          -- Path to the input PDB file for the ligand (e.g., "ligand.pdb")
    prmtop_file        -- Path to the output topology file (.prmtop) to be generated (e.g., "system.prmtop")
    inpcrd_file        -- Path to the output coordinates file (.inpcrd) to be generated (e.g., "system.inpcrd")
    solvated_pdb_file  -- Path to the output solvated PDB file (e.g., "system.pdb")
    tleap_file         -- Path to the tleap script to be created and executed (e.g., "solvate.tleap")
    box_size           -- Size of the chloroform solvent box (e.g., 10.0)
    
    This function writes a `tleap` input script, which:
    - Loads the ligand's prepared files (.prepin, .frcmod, .lib)
    - Loads the PDB file of the ligand
    - Solvates the ligand in a box of chloroform (CHCL3BOX)
    - Saves the solvated system as .prmtop, .inpcrd, and .pdb files
    
    After creating the script, the function automatically runs it using the tleap command.
    """

    # Create the tleap script content
    script_content = f"""
source leaprc.protein.ff14SB
source leaprc.gaff
loadoff solvents.lib
loadAmberParams frcmod.chcl3
loadamberprep {prepin_file}
loadamberparams {frcmod_file}
loadoff {lib_file}
mol = loadpdb {input_pdb}
solvateBox mol CHCL3BOX {box_size}
saveamberparm mol {prmtop_file} {inpcrd_file}
savepdb mol {solvated_pdb_file}
charge mol
quit
"""
    # Write the tleap script to the specified file
    with open(tleap_file, "w") as script_file:
        script_file.write(script_content)
    print(f"Created {tleap_file} tleap script for solvation.")

    # Run the tleap script to solvate the ligand
    tleap_command = f"tleap -f {tleap_file}"
    os.system(tleap_command)
    print(f"Ran tleap using script: {tleap_file}. Solvation completed.")


def get_xml(prmtop_file, pdb_file, xml_file):
    """
    Loads the AMBER topology from the prmtop file and coordinates from the PDB file, and saves the system as an XML file.
    
    Arguments:
    prmtop_file -- Path to the AMBER topology file (e.g., 'system.prmtop')
    pdb_file    -- Path to the PDB file for the system (e.g., 'system.pdb')
    xml_output  -- Path to save the system XML file (e.g., 'system.xml')
    """
    # Load the AMBER topology file and PDB file for coordinates and topology
    prmtop = app.AmberPrmtopFile(prmtop_file)
    pdb = app.PDBFile(pdb_file)
    
    # Set up the system
    system = prmtop.createSystem(nonbondedMethod=app.PME, 
                                 nonbondedCutoff=1.0*unit.nanometers, 
                                 constraints=app.HBonds)
    # Save the force field parameters to XML
    with open(xml_file, 'w') as f:
        f.write(openmm.XmlSerializer.serialize(system))
    print(f"System saved as XML file: {xml_file}")

def run_simulation_with_solvent(xml_file, pdb_file, steps, dcd_output, platform, temperature, friction, timestep, save_frequency, output_pdb):
    """
    Loads the system from an XML file and runs MD simulations.
    
    Arguments:
    xml_file   -- Path to the XML file containing the serialized system information (e.g., 'system.xml')
    pdb_file   -- Path to the PDB file for topology and initial positions (e.g., 'system.pdb')
    steps      -- Number of simulation steps to run (e.g., 50000)
    dcd_output -- File path for saving the simulation trajectory (e.g., 'trajectory.dcd')
    platform   -- The computing platform to use for running the simulation (e.g., 'CUDA', 'CPU')
    temperature -- Target temperature for the Langevin thermostat, in Kelvin (e.g., 300.0)
    friction   -- Friction coefficient for Langevin dynamics, in 1/ps (e.g., 1.0)
    timestep   -- Integration time step for the simulation, in picoseconds (e.g., 0.002)
    save_frequency -- Frequency of saving the trajectory and state information (e.g., every 500 steps)
    output_pdb -- File path for saving the final atomic positions in PDB format (e.g., 'final_positions.pdb')
    """
    # Load system from XML
    with open(xml_file, 'r') as f:
        system = openmm.XmlSerializer.deserialize(f.read())
    # Load topology and initial positions from the PDB file
    pdb = app.PDBFile(pdb_file)
    # Define the integrator (Langevin Dynamics) for temperature control
    integrator = openmm.LangevinIntegrator(temperature*unit.kelvin,    # Temperature
                                           friction/unit.picoseconds,  # Friction coefficient
                                           timestep*unit.picoseconds)  # Time step (2 fs)
    # Set up the simulation
    platform = openmm.Platform.getPlatformByName(platform)  
    simulation = app.Simulation(pdb.topology, system, integrator, platform)
    # Set initial positions from the PDB file
    simulation.context.setPositions(pdb.positions)
    # Apply periodic boundary conditions if necessary
    if pdb.topology.getPeriodicBoxVectors() is not None:
        simulation.context.setPeriodicBoxVectors(*pdb.topology.getPeriodicBoxVectors())
    # Print energy before minimization
    state = simulation.context.getState(getEnergy=True)
    print("Potential Energy before minimization: ", state.getPotentialEnergy())
    # Energy minimization
    print("Minimizing energy...")
    simulation.minimizeEnergy(maxIterations=100000)
    # Print energy after minimization
    state = simulation.context.getState(getEnergy=True)
    print("Potential Energy after minimization: ", state.getPotentialEnergy())
    # Set up reporters to save outputs
    simulation.reporters.append(app.StateDataReporter(stdout, save_frequency, step=True, potentialEnergy=True, temperature=True, speed=True))
    simulation.reporters.append(app.DCDReporter(dcd_output, save_frequency))  # Save the trajectory
    # Run the simulation for the specified number of steps
    print(f"Running simulation for {steps} steps...")
    simulation.step(steps)
    # Save the final positions to a PDB file
    positions = simulation.context.getState(getPositions=True).getPositions()
    with open(output_pdb, 'w') as output:
        app.PDBFile.writeFile(simulation.topology, positions, output)

def extract_ligand(input_pdb, residue_name, ligand_pdb_file):
    """
    Extracts a ligand with a specific residue name and residue number from a PDB file and writes it to a new PDB file.
    
    Arguments:
    input_pdb       -- Path to the input PDB file (e.g., "system.pdb")
    residue_name    -- The residue name of the ligand (e.g., "LIG")
    ligand_pdb_file -- Path to the output PDB file for the extracted ligand (e.g., "ligand.pdb")
    """
    with open(input_pdb, 'r') as infile, open(ligand_pdb_file, 'w') as outfile:
        for line in infile:
            # Check if the line is an ATOM or HETATM record
            if line.startswith("HETATM") or line.startswith("ATOM"):
                # Extract the residue name from the line (columns 18-20 in PDB format)
                current_residue = line[17:20].strip()
                
                # Check if the current line belongs to the desired residue
                if current_residue == residue_name:
                    outfile.write(line)
    
    print(f"Ligand {residue_name} extracted to {ligand_pdb_file}")

def pdb_to_sdf(input_pdb, output_sdf):
    """
    Converts a PDB file to an SDF file using OpenEye's OEChem toolkit.
    
    Parameters:
    - input_pdb: str, path to the input PDB file
    - output_sdf: str, path to the output SDF file
    """
    # Create input and output molecule streams
    ifs = oechem.oemolistream()
    ofs = oechem.oemolostream()
    # Open input PDB file and output SDF file
    if not ifs.open(input_pdb):
        oechem.OEThrow.Fatal(f"Unable to open the input PDB file: {input_pdb}")
    if not ofs.open(output_sdf):
        oechem.OEThrow.Fatal(f"Unable to create the output SDF file: {output_sdf}")
    # Convert PDB to SDF using a generator for reading molecules
    for mol in ifs.GetOEGraphMols():
        oechem.OEWriteMolecule(ofs, mol)
    # Close the streams
    ifs.close()
    ofs.close()
    print(f"Successfully converted {input_pdb} to {output_sdf}.")

def rdkitize_sdf(input_sdf, output_sdf):
    """
    Automates the modification of an SDF file by assigning 0 to relevant columns and removing charge information.
    
    Parameters:
    ----------
    input_sdf : str
        Path to the input SDF file to be modified.
    output_sdf : str
        Path to the output modified SDF file.
    
    """
    # Read the input SDF file
    suppl = Chem.SDMolSupplier(input_sdf, removeHs=False)
    # Check if the input file was correctly loaded
    if not suppl:
        raise FileNotFoundError(f"Unable to read the file: {input_sdf}")
    # Open the output SDF file for writing
    writer = Chem.SDWriter(output_sdf)
    # Iterate through the molecules in the input file
    for mol in suppl:
        if mol is None:
            continue
        # Iterate through the atoms of the molecule
        for atom in mol.GetAtoms():
            # Set atom properties like stereo parity and hydrogens to 0
            atom.SetProp('_Stereo', '0')  # Set stereo parity to 0
            atom.SetNumExplicitHs(0)      # Set explicit hydrogen count to 0
            # Remove formal charges
            atom.SetFormalCharge(0)
        # Write the modified molecule to the output SDF
        writer.write(mol)
    # Close the writer
    writer.close()
    print(f"Modified SDF saved to: {output_sdf}")

def parameterize_ligand(ligand_sdf, xml_file, espaloma_version, log_file=None):
    """
    Parameterize a ligand molecule using the Espaloma model and serialize the force field parameters as an OpenMM XML file.

    Parameters:
    ----------
    ligand_sdf : str
        Path to the ligand SDF file to be parameterized.
    xml_file : str
        Path to the output XML file where the parameterized force field will be serialized.
    espaloma_version : str
        The version of the Espaloma model to use for parameterization.
    log_file : str, optional
        Optional log file to log progress.

    Returns:
    -------
    None
        The function serializes the parameterized ligand into an XML file.
    """
    def log(message, log_file=None):
        """Utility function to print and log messages."""
        print(message)
        if log_file:
            with open(log_file, 'a') as log_f:
                log_f.write(message + '\n')
    # Load the ligand from the provided SDF file
    log(f"Loading ligand from SDF file: {ligand_sdf}", log_file)
    mol = Molecule.from_file(ligand_sdf)
    # Convert the molecule to an Espaloma graph
    log('Converting molecule to Espaloma graph', log_file)
    mol_graph = esp.Graph(mol)
    # Load the Espaloma model (neural network for parameter prediction)
    log(f'Loading Espaloma model (version {espaloma_version})', log_file)
    espaloma_model = esp.get_model(espaloma_version)
    # Apply the Espaloma model to the molecular graph for parameterization
    log('Applying the Espaloma model to parameterize the ligand', log_file)
    espaloma_model(mol_graph.heterograph)
    # Convert the Espaloma graph to an OpenMM system
    log('Generating OpenMM system from Espaloma parameters', log_file)
    openmm_system: openmm.System = esp.graphs.deploy.openmm_system_from_graph(mol_graph)
    # Serialize the parameterized OpenMM system into an XML file
    log(f'Serializing OpenMM system to {xml_file}', log_file)
    with open(xml_file, 'w') as f:
        f.write(openmm.XmlSerializer.serialize(openmm_system))
    log(f"Successfully saved parameterized ligand to {xml_file}", log_file)

def get_threshold(system_file, ligand_file):
    """
    Loads system.xml and ligand.xml into OpenMM systems, calculates the threshold based on the number of atoms in
    the ligand system, and returns the system, ligand system, and threshold.

    Parameters:
    system_file (str): Path to the system XML file.
    ligand_file (str): Path to the ligand XML file.

    Returns:
    system (openmm.System): The OpenMM system loaded from system.xml.
    ligand_system (openmm.System): The OpenMM system loaded from ligand.xml.
    threshold (int): The number of atoms in the ligand system, used as the threshold.
    """
    # Load system.xml into an OpenMM system
    with open(system_file, 'r') as sys_file:
        system = XmlSerializer.deserialize(sys_file.read())
    # Load ligand.xml into an OpenMM system
    with open(ligand_file, 'r') as lig_file:
        ligand_system = XmlSerializer.deserialize(lig_file.read())
    # Calculate the threshold based on the number of atoms in the ligand system
    threshold = ligand_system.getNumParticles()
    # Print the number of atoms in each system for verification
    print(f"Number of atoms in system: {system.getNumParticles()}")
    print(f"Number of atoms in ligand: {ligand_system.getNumParticles()}")
    return threshold

def generate_template_xml(input_file, output_file, tags_to_remove):
    """
    Reads an XML file, clears the content between specific tags while keeping the tags themselves,
    and writes the cleaned XML content to a new output file.

    Parameters:
    input_file (str): Path to the input XML file.
    output_file (str): Path to the output XML file where the cleaned content will be written.
    tags_to_remove (list of tuples): A list of tuples where each tuple contains a start tag and an end tag.
                                     The content between these tags will be removed, but the tags themselves
                                     will be preserved.
    """
    
    def clear_content_between_tags(lines, start_tag, end_tag):
        """
        Clears the content between the specified start and end tags, while preserving the tags themselves.

        Parameters:
        lines (list): List of lines from the input XML file.
        start_tag (str): The start tag marking the beginning of the block whose content will be cleared.
        end_tag (str): The end tag marking the end of the block whose content will be cleared.

        Returns:
        list: A list of lines where content between the specified tags has been cleared.
        """
        in_block = False
        cleaned_lines = []
        for line in lines:
            if start_tag in line:
                in_block = True
                cleaned_lines.append(line)  # Keep the start tag
            elif end_tag in line:
                in_block = False
                cleaned_lines.append(line)  # Keep the end tag
            elif not in_block:
                cleaned_lines.append(line)
        return cleaned_lines
    # Reading the input XML file
    with open(input_file, 'r') as file:
        lines = file.readlines()
    # Clear content but keep the tags for each specified block
    for start_tag, end_tag in tags_to_remove:
        lines = clear_content_between_tags(lines, start_tag, end_tag)
    # Writing the updated lines to the output file
    with open(output_file, 'w') as file:
        file.writelines(lines)

def add_bond_forces_template(system_file, ligand_file, threshold, template_file):
    """
    Processes bond forces from `system.xml` and `ligand.xml`, combines them, and inserts the combined bond
    forces into the `<Bonds>` section of `template.xml`. The function directly modifies `template.xml`.

    Parameters:
    system_file (str): Path to the system XML file containing bonds that will be filtered based on the threshold.
    ligand_file (str): Path to the ligand XML file containing bond information that will be extracted.
    threshold (int): The value used to filter the bonds in `system.xml`. Only bonds where both `p1` and `p2` 
                     are greater than or equal to this threshold are kept.
    template_file (str): Path to the template XML file where the combined bond forces will be inserted into 
                         the `<Bonds>` section.
    """
    
    # Function to extract and filter <Bonds> content from system.xml
    def extract_and_filter_bond_lines(lines, threshold):
        """
        Extracts bond lines from the system XML file where both `p1` and `p2` values are greater than or 
        equal to the threshold.

        Parameters:
        lines (list): List of lines from the system XML file.
        threshold (int): The minimum value for `p1` and `p2` to keep a bond line.

        Returns:
        list: A list of filtered bond lines that meet the threshold criteria.
        """
        start_tag = '<Bonds>'
        end_tag = '</Bonds>'
        in_block = False
        extracted_and_filtered_lines = []
        for line in lines:
            stripped_line = line.strip()
            if start_tag in stripped_line:
                in_block = True
                continue  # Skip the line with <Bonds>
            if end_tag in stripped_line:
                break
            if in_block:
                # Extract values of p1 and p2
                p1_index = line.find('p1="') + 4
                p2_index = line.find('p2="') + 4
                if p1_index != -1 and p2_index != -1:
                    p1_value = int(line[p1_index:line.find('"', p1_index)])
                    p2_value = int(line[p2_index:line.find('"', p2_index)])
                    if p1_value >= threshold and p2_value >= threshold:
                        extracted_and_filtered_lines.append(line)
        return extracted_and_filtered_lines
    
    # Function to extract <Bonds> content from ligand.xml
    def extract_bond_lines(lines):
        """
        Extracts bond lines from the ligand XML file.

        Parameters:
        lines (list): List of lines from the ligand XML file.

        Returns:
        list: A list of bond lines extracted from the <Bonds> section of the ligand file.
        """
        start_tag = '<Bonds>'
        end_tag = '</Bonds>'
        in_block = False
        extracted_lines = []
        for line in lines:
            stripped_line = line.strip()
            if start_tag in stripped_line:
                in_block = True
                continue  # Skip the line with <Bonds>
            if end_tag in stripped_line:
                break
            if in_block:
                extracted_lines.append(line)
        return extracted_lines
    # Read and process the system.xml file
    with open(system_file, 'r') as system_file_obj:
        system_lines = system_file_obj.readlines()
    filtered_system_bond_lines = extract_and_filter_bond_lines(system_lines, threshold)
    # Read and process the ligand.xml file
    with open(ligand_file, 'r') as ligand_file_obj:
        ligand_lines = ligand_file_obj.readlines()
    ligand_bond_lines = extract_bond_lines(ligand_lines)
    # Combine bond lines from ligand.xml and filtered system.xml bond lines
    combined_bond_lines = ligand_bond_lines + filtered_system_bond_lines
    # Insert combined bond lines into the template.xml
    with open(template_file, 'r') as template_file_obj:
        template_lines = template_file_obj.readlines()
    new_lines = []
    in_bonds_section = False
    for line in template_lines:
        stripped_line = line.strip()
        if '<Bonds>' in stripped_line:
            new_lines.append(line)  # Append the <Bonds> line with original indentation
            in_bonds_section = True
            # Add combined bond lines with the same indentation as <Bonds>
            for bond_line in combined_bond_lines:
                new_lines.append(' ' * line.index('<Bonds>') + bond_line)
        elif '</Bonds>' in stripped_line and in_bonds_section:
            in_bonds_section = False
            new_lines.append(line)  # Append the </Bonds> line as it is, keeping the indentation
        else:
            new_lines.append(line)  # Append all other lines as usual
    # Overwrite the template.xml file with the updated content
    with open(template_file, 'w') as output_file:
        output_file.writelines(new_lines)

def add_angle_forces_template(system_file, ligand_file, threshold, template_file):
    """
    Processes angle forces from `system.xml` and `ligand.xml`, combines them, and inserts the combined angle
    forces into the `<Angles>` section of `template.xml`. The function directly modifies `template.xml`.

    Parameters:
    system_file (str): Path to the system XML file containing angles that will be filtered based on the threshold.
    ligand_file (str): Path to the ligand XML file containing angle information that will be extracted.
    threshold (int): The value used to filter the angles in `system.xml`. Only angles where `p1`, `p2`, and `p3` 
                     are greater than or equal to this threshold are kept.
    template_file (str): Path to the template XML file where the combined angle forces will be inserted into 
                         the `<Angles>` section.
    """
    
    # Function to extract and filter <Angles> content from system.xml
    def extract_and_filter_angle_lines(lines, threshold):
        """
        Extracts angle lines from the system XML file where `p1`, `p2`, and `p3` values are greater than or 
        equal to the threshold.

        Parameters:
        lines (list): List of lines from the system XML file.
        threshold (int): The minimum value for `p1`, `p2`, and `p3` to keep an angle line.

        Returns:
        list: A list of filtered angle lines that meet the threshold criteria.
        """
        start_tag = '<Angles>'
        end_tag = '</Angles>'
        in_block = False
        extracted_and_filtered_lines = []
        for line in lines:
            stripped_line = line.strip()
            if start_tag in stripped_line:
                in_block = True
                continue  # Skip the line with <Angles>
            if end_tag in stripped_line:
                break
            if in_block:
                # Extract values of p1, p2, and p3
                p1_index = line.find('p1="') + 4
                p2_index = line.find('p2="') + 4
                p3_index = line.find('p3="') + 4
                if p1_index != -1 and p2_index != -1 and p3_index != -1:
                    p1_value = int(line[p1_index:line.find('"', p1_index)])
                    p2_value = int(line[p2_index:line.find('"', p2_index)])
                    p3_value = int(line[p3_index:line.find('"', p3_index)])
                    if p1_value >= threshold and p2_value >= threshold and p3_value >= threshold:
                        extracted_and_filtered_lines.append(line)
        return extracted_and_filtered_lines
    # Function to extract <Angles> content from ligand.xml
    def extract_angle_lines(lines):
        """
        Extracts angle lines from the ligand XML file.

        Parameters:
        lines (list): List of lines from the ligand XML file.

        Returns:
        list: A list of angle lines extracted from the <Angles> section of the ligand file.
        """
        start_tag = '<Angles>'
        end_tag = '</Angles>'
        in_block = False
        extracted_lines = []
        for line in lines:
            stripped_line = line.strip()
            if start_tag in stripped_line:
                in_block = True
                continue  # Skip the line with <Angles>
            if end_tag in stripped_line:
                break
            if in_block:
                extracted_lines.append(line)
        return extracted_lines
    # Read and process the system.xml file
    with open(system_file, 'r') as system_file_obj:
        system_lines = system_file_obj.readlines()
    filtered_system_angle_lines = extract_and_filter_angle_lines(system_lines, threshold)
    # Read and process the ligand.xml file
    with open(ligand_file, 'r') as ligand_file_obj:
        ligand_lines = ligand_file_obj.readlines()
    ligand_angle_lines = extract_angle_lines(ligand_lines)
    # Combine angle lines from ligand.xml and filtered system.xml angle lines
    combined_angle_lines = ligand_angle_lines + filtered_system_angle_lines
    # Insert combined angle lines into the template.xml
    with open(template_file, 'r') as template_file_obj:
        template_lines = template_file_obj.readlines()
    new_lines = []
    in_angles_section = False
    for line in template_lines:
        stripped_line = line.strip()
        if '<Angles>' in stripped_line:
            new_lines.append(line)  # Append the <Angles> line with original indentation
            in_angles_section = True
            # Add combined angle lines with the same indentation as <Angles>
            for angle_line in combined_angle_lines:
                new_lines.append(' ' * line.index('<Angles>') + angle_line)
        elif '</Angles>' in stripped_line and in_angles_section:
            in_angles_section = False
            new_lines.append(line)  # Append the </Angles> line as it is, keeping the indentation
        else:
            new_lines.append(line)  # Append all other lines as usual
    # Overwrite the template.xml file with the updated content
    with open(template_file, 'w') as output_file:
        output_file.writelines(new_lines)

def add_torsion_forces_template(system_file, ligand_file, threshold, template_file):
    """
    Processes torsion forces from `system.xml` and `ligand.xml`, combines them, and inserts the combined torsion
    forces into the `<Torsions>` section of `template.xml`. The function directly modifies `template.xml`.

    Parameters:
    system_file (str): Path to the system XML file containing torsions that will be filtered based on the threshold.
    ligand_file (str): Path to the ligand XML file containing torsion information that will be extracted.
    threshold (int): The value used to filter the torsions in `system.xml`. Only torsions where `p1`, `p2`, `p3`, 
                     and `p4` are greater than or equal to this threshold are kept.
    template_file (str): Path to the template XML file where the combined torsion forces will be inserted into 
                         the `<Torsions>` section.
    """
    
    # Function to extract and filter <Torsions> content from system.xml
    def extract_and_filter_torsion_lines(lines, threshold):
        """
        Extracts torsion lines from the system XML file where `p1`, `p2`, `p3`, and `p4` values are greater than 
        or equal to the threshold.

        Parameters:
        lines (list): List of lines from the system XML file.
        threshold (int): The minimum value for `p1`, `p2`, `p3`, and `p4` to keep a torsion line.

        Returns:
        list: A list of filtered torsion lines that meet the threshold criteria.
        """
        start_tag = '<Torsions>'
        end_tag = '</Torsions>'
        in_block = False
        extracted_and_filtered_lines = []
        for line in lines:
            stripped_line = line.strip()
            if start_tag in stripped_line:
                in_block = True
                continue  # Skip the line with <Torsions>
            if end_tag in stripped_line:
                break
            if in_block:
                # Extract values of p1, p2, p3, and p4
                p1_index = line.find('p1="') + 4
                p2_index = line.find('p2="') + 4
                p3_index = line.find('p3="') + 4
                p4_index = line.find('p4="') + 4
                if p1_index != -1 and p2_index != -1 and p3_index != -1 and p4_index != -1:
                    p1_value = int(line[p1_index:line.find('"', p1_index)])
                    p2_value = int(line[p2_index:line.find('"', p2_index)])
                    p3_value = int(line[p3_index:line.find('"', p3_index)])
                    p4_value = int(line[p4_index:line.find('"', p4_index)])
                    if p1_value >= threshold and p2_value >= threshold and p3_value >= threshold and p4_value >= threshold:
                        extracted_and_filtered_lines.append(line)
        return extracted_and_filtered_lines
    
    # Function to extract <Torsions> content from ligand.xml
    def extract_torsion_lines(lines):
        """
        Extracts torsion lines from the ligand XML file.

        Parameters:
        lines (list): List of lines from the ligand XML file.

        Returns:
        list: A list of torsion lines extracted from the <Torsions> section of the ligand file.
        """
        start_tag = '<Torsions>'
        end_tag = '</Torsions>'
        in_block = False
        extracted_lines = []
        for line in lines:
            stripped_line = line.strip()
            if start_tag in stripped_line:
                in_block = True
                continue  # Skip the line with <Torsions>
            if end_tag in stripped_line:
                break
            if in_block:
                extracted_lines.append(line)
        return extracted_lines
    # Read and process the system.xml file
    with open(system_file, 'r') as system_file_obj:
        system_lines = system_file_obj.readlines()
    filtered_system_torsion_lines = extract_and_filter_torsion_lines(system_lines, threshold)
    # Read and process the ligand.xml file
    with open(ligand_file, 'r') as ligand_file_obj:
        ligand_lines = ligand_file_obj.readlines()
    ligand_torsion_lines = extract_torsion_lines(ligand_lines)
    # Combine torsion lines from ligand.xml and filtered system.xml torsion lines
    combined_torsion_lines = ligand_torsion_lines + filtered_system_torsion_lines
    # Insert combined torsion lines into the template.xml
    with open(template_file, 'r') as template_file_obj:
        template_lines = template_file_obj.readlines()
    new_lines = []
    in_torsions_section = False
    for line in template_lines:
        stripped_line = line.strip()
        if '<Torsions>' in stripped_line:
            new_lines.append(line)  # Append the <Torsions> line with original indentation
            in_torsions_section = True
            # Add combined torsion lines with the same indentation as <Torsions>
            for torsion_line in combined_torsion_lines:
                new_lines.append(' ' * line.index('<Torsions>') + torsion_line)
        elif '</Torsions>' in stripped_line and in_torsions_section:
            in_torsions_section = False
            new_lines.append(line)  # Append the </Torsions> line as it is, keeping the indentation
        else:
            new_lines.append(line)  # Append all other lines as usual
    # Overwrite the template.xml file with the updated content
    with open(template_file, 'w') as output_file:
        output_file.writelines(new_lines)

def add_exception_forces_template(system_file, ligand_file, threshold, template_file):
    """
    Processes exception forces from `system.xml` and `ligand.xml`, combines them, and inserts the combined exception
    forces into the `<Exceptions>` section of `template.xml`. The function directly modifies `template.xml`.

    Parameters:
    system_file (str): Path to the system XML file containing exceptions that will be filtered based on the threshold.
    ligand_file (str): Path to the ligand XML file containing exception information that will be extracted.
    threshold (int): The value used to filter the exceptions in `system.xml`. Only exceptions where `p1` and `p2` 
                     are greater than or equal to this threshold are kept.
    template_file (str): Path to the template XML file where the combined exception forces will be inserted into 
                         the `<Exceptions>` section.
    """
    
    # Function to extract and filter <Exceptions> content from system.xml
    def extract_and_filter_exception_lines(lines, threshold):
        """
        Extracts exception lines from the system XML file where `p1` and `p2` values are greater than or 
        equal to the threshold.

        Parameters:
        lines (list): List of lines from the system XML file.
        threshold (int): The minimum value for `p1` and `p2` to keep an exception line.

        Returns:
        list: A list of filtered exception lines that meet the threshold criteria.
        """
        start_tag = '<Exceptions>'
        end_tag = '</Exceptions>'
        in_block = False
        extracted_and_filtered_lines = []
        for line in lines:
            stripped_line = line.strip()
            if start_tag in stripped_line:
                in_block = True
                continue  # Skip the line with <Exceptions>
            if end_tag in stripped_line:
                break
            if in_block:
                # Extract values of p1 and p2
                p1_index = line.find('p1="') + 4
                p2_index = line.find('p2="') + 4
                if p1_index != -1 and p2_index != -1:
                    p1_value = int(line[p1_index:line.find('"', p1_index)])
                    p2_value = int(line[p2_index:line.find('"', p2_index)])
                    if p1_value >= threshold and p2_value >= threshold:
                        extracted_and_filtered_lines.append(line)
        return extracted_and_filtered_lines
    
    # Function to extract <Exceptions> content from ligand.xml
    def extract_exception_lines(lines):
        """
        Extracts exception lines from the ligand XML file.

        Parameters:
        lines (list): List of lines from the ligand XML file.

        Returns:
        list: A list of exception lines extracted from the <Exceptions> section of the ligand file.
        """
        start_tag = '<Exceptions>'
        end_tag = '</Exceptions>'
        in_block = False
        extracted_lines = []
        for line in lines:
            stripped_line = line.strip()
            if start_tag in stripped_line:
                in_block = True
                continue  # Skip the line with <Exceptions>
            if end_tag in stripped_line:
                break
            if in_block:
                extracted_lines.append(line)
        return extracted_lines
    # Read and process the system.xml file
    with open(system_file, 'r') as system_file_obj:
        system_lines = system_file_obj.readlines()
    filtered_system_exception_lines = extract_and_filter_exception_lines(system_lines, threshold)
    # Read and process the ligand.xml file
    with open(ligand_file, 'r') as ligand_file_obj:
        ligand_lines = ligand_file_obj.readlines()
    ligand_exception_lines = extract_exception_lines(ligand_lines)
    # Combine exception lines from ligand.xml and filtered system.xml exception lines
    combined_exception_lines = ligand_exception_lines + filtered_system_exception_lines
    # Insert combined exception lines into the template.xml
    with open(template_file, 'r') as template_file_obj:
        template_lines = template_file_obj.readlines()
    new_lines = []
    in_exceptions_section = False
    for line in template_lines:
        stripped_line = line.strip()
        if '<Exceptions>' in stripped_line:
            new_lines.append(line)  # Append the <Exceptions> line with original indentation
            in_exceptions_section = True
            # Add combined exception lines with the same indentation as <Exceptions>
            for exception_line in combined_exception_lines:
                new_lines.append(' ' * line.index('<Exceptions>') + exception_line)
        elif '</Exceptions>' in stripped_line and in_exceptions_section:
            in_exceptions_section = False
            new_lines.append(line)  # Append the </Exceptions> line as it is, keeping the indentation
        else:
            new_lines.append(line)  # Append all other lines as usual
    # Overwrite the template.xml file with the updated content
    with open(template_file, 'w') as output_file:
        output_file.writelines(new_lines)

def process_mass_template(system_file, ligand_file, template_file, threshold):
    """
    Processes particle forces from `system.xml` and `ligand.xml`, combines them, and inserts the combined particle
    forces into the first `<Particles>` section of `template.xml`. The function directly modifies `template.xml`.

    Parameters:
    system_file (str): Path to the system XML file containing particles.
    ligand_file (str): Path to the ligand XML file containing particle information.
    threshold (int): The number of particle lines to remove from the system.xml file.
    template_file (str): Path to the template XML file where the combined particle forces will be inserted into 
                         the first `<Particles>` section.
    """
    
    # Function to extract the lines between the first occurrence of <Particles> and </Particles>
    def extract_particle_lines(lines):
        """
        Extracts lines between the first <Particles> and </Particles> section in the given XML file.

        Parameters:
        lines (list): List of lines from the XML file.

        Returns:
        list: A list of lines between the first occurrence of <Particles> and </Particles>.
        """
        start_tag = '<Particles>'
        end_tag = '</Particles>'
        in_block = False
        extracted_lines = []
        for line in lines:
            stripped_line = line.strip()
            if start_tag in stripped_line and not in_block:
                in_block = True
                continue  # Skip the <Particles> tag
            if end_tag in stripped_line and in_block:
                break  # Stop at the </Particles> tag
            if in_block:
                extracted_lines.append(line)
        return extracted_lines
    # Extract all particle lines from system.xml
    with open(system_file, 'r') as system_file_obj:
        system_lines = system_file_obj.readlines()
    system_particle_lines = extract_particle_lines(system_lines)
    # Remove the first `threshold` lines from the system particle lines
    system_particle_lines_trimmed = system_particle_lines[threshold:]
    # Extract all particle lines from ligand.xml
    with open(ligand_file, 'r') as ligand_file_obj:
        ligand_lines = ligand_file_obj.readlines()
    ligand_particle_lines = extract_particle_lines(ligand_lines)
    # Combine the ligand.xml lines first, followed by the remaining system.xml lines
    combined_particle_lines = ligand_particle_lines + system_particle_lines_trimmed
    # Insert combined particle lines into the first occurrence of <Particles> in the template.xml
    with open(template_file, 'r') as template_file_obj:
        template_lines = template_file_obj.readlines()
    new_lines = []
    in_particles_section = False
    particles_inserted = False  # This will help ensure the insertion happens only once
    for line in template_lines:
        stripped_line = line.strip()
        if '<Particles>' in stripped_line and not particles_inserted:
            new_lines.append(line)  # Append the <Particles> line with original indentation
            in_particles_section = True
            # Add combined particle lines with the same indentation as <Particles>
            for particle_line in combined_particle_lines:
                new_lines.append(' ' * line.index('<Particles>') + particle_line)
            particles_inserted = True  # Ensure we only insert once
        elif '</Particles>' in stripped_line and in_particles_section:
            in_particles_section = False
            new_lines.append(line)  # Append the </Particles> line as it is, keeping the indentation
        else:
            new_lines.append(line)  # Append all other lines as usual
    # Overwrite the template.xml file with the updated content
    with open(template_file, 'w') as output_file:
        output_file.writelines(new_lines)

def process_lj_template(system_file, ligand_file, template_file, threshold):
    """
    Processes particle forces from `system.xml` and `ligand.xml`, combines them, and inserts the combined particle
    forces into the second `<Particles>` section of `template.xml`. The function directly modifies `template.xml`.

    Parameters:
    system_file (str): Path to the system XML file containing particles.
    ligand_file (str): Path to the ligand XML file containing particle information.
    threshold (int): The number of particle lines to remove from the system.xml file.
    template_file (str): Path to the template XML file where the combined particle forces will be inserted into 
                         the second `<Particles>` section.
    """
    
    # Function to extract the lines between the second occurrence of <Particles> and </Particles>
    def extract_second_particle_lines(lines):
        """
        Extracts lines between the second <Particles> and </Particles> section in the given XML file.

        Parameters:
        lines (list): List of lines from the XML file.

        Returns:
        list: A list of lines between the second occurrence of <Particles> and </Particles>.
        """
        start_tag = '<Particles>'
        end_tag = '</Particles>'
        in_block = False
        occurrence = 0
        extracted_lines = []
        for line in lines:
            stripped_line = line.strip()
            if start_tag in stripped_line:
                occurrence += 1
                if occurrence == 2:
                    in_block = True
                    continue  # Skip the second <Particles> tag
            if end_tag in stripped_line and in_block:
                break  # Stop at the second </Particles> tag
            if in_block:
                extracted_lines.append(line)
        return extracted_lines
    # Extract all particle lines from the second <Particles> section in system.xml
    with open(system_file, 'r') as system_file_obj:
        system_lines = system_file_obj.readlines()
    system_particle_lines = extract_second_particle_lines(system_lines)
    # Remove the first `threshold` lines from the system particle lines
    system_particle_lines_trimmed = system_particle_lines[threshold:]
    # Extract all particle lines from the second <Particles> section in ligand.xml
    with open(ligand_file, 'r') as ligand_file_obj:
        ligand_lines = ligand_file_obj.readlines()
    ligand_particle_lines = extract_second_particle_lines(ligand_lines)
    # Combine the ligand.xml lines first, followed by the remaining system.xml lines
    combined_particle_lines = ligand_particle_lines + system_particle_lines_trimmed
    # Insert combined particle lines into the second occurrence of <Particles> in the template.xml
    with open(template_file, 'r') as template_file_obj:
        template_lines = template_file_obj.readlines()
    new_lines = []
    in_particles_section = False
    occurrence = 0
    for line in template_lines:
        stripped_line = line.strip()
        if '<Particles>' in stripped_line:
            occurrence += 1
            if occurrence == 2:
                new_lines.append(line)  # Append the second <Particles> line with original indentation
                in_particles_section = True
                # Add combined particle lines with the same indentation as <Particles>
                for particle_line in combined_particle_lines:
                    new_lines.append(' ' * line.index('<Particles>') + particle_line)
            else:
                new_lines.append(line)  # Append the first <Particles> line as usual (not modifying)
        elif '</Particles>' in stripped_line and in_particles_section:
            in_particles_section = False
            new_lines.append(line)  # Append the second </Particles> line as it is, keeping the indentation
        else:
            new_lines.append(line)  # Append all other lines as usual
    # Overwrite the template.xml file with the updated content
    with open(template_file, 'w') as output_file:
        output_file.writelines(new_lines)


def copy_file(source_file, file_name):
    """
    Copies a file to a new location with a new name using shell commands.
    
    Parameters:
    - source_file: str, path to the source file
    - file_name: str, the path and new name for the copied file
    """
    # Copy the file using cp command
    try:
        subprocess.run(["cp", "-r", source_file, file_name], check=True)
        print(f"File copied from {source_file} to {file_name}.")
    except subprocess.CalledProcessError as e:
        print(f"Error copying file: {e}")
        return

def delete_file(file):
    """
    Deletes a file at the specified path.
    
    Parameters:
    - file: str, path to the file to be deleted
    """
    try:
        # Check if the file exists
        if os.path.exists(file):
            # Delete the file
            os.remove(file)
            print(f"File {file} deleted successfully.")
        else:
            print(f"File {file} does not exist.")
    except Exception as e:
        print(f"Error deleting file: {e}")

def move_files(files):
    """
    Moves all files in the current directory to a directory named 'intermediate_files',
    except for specified excluded files and files ending with '.ipynb' or '.py'.
    
    Parameters:
    - files: list of str, file names to exclude from moving (e.g., ['system.xml', 'system.pdb', 'ligand_n.sdf'])
    """
    # Directory name
    directory = "intermediate_files"
    # Excluded extensions
    excluded_extensions = ['.ipynb', '.py']
    # Create the directory if it doesn't exist
    if not os.path.exists(directory):
        os.makedirs(directory)
        print(f"Directory '{directory}' created.")
    else:
        print(f"Directory '{directory}' already exists.")
    
    # Get the list of all files in the current directory
    all_files = [f for f in os.listdir() if os.path.isfile(f)]
    # Move files to the directory, excluding specified files and extensions
    for file_name in all_files:
        file_extension = os.path.splitext(file_name)[1]
        # Skip files that are in the excluded list or have excluded extensions
        if file_name not in files and file_extension not in excluded_extensions:
            try:
                shutil.move(file_name, os.path.join(directory, file_name))
                print(f"Moved {file_name} to {directory}.")
            except Exception as e:
                print(f"Error moving {file_name}: {e}")
        else:
            print(f"Skipped {file_name}.")

def strip_trajectory(trajectory_file: str, topology_file: str, ligand_resname: str, output_file: str, log_file=None):
    """
    Strips the specified ligand from a trajectory file and saves it as a PDB file.

    Parameters:
    ----------
    trajectory_file : str
        Path to the input trajectory file.
    topology_file : str
        Path to the topology file containing system information.
    ligand_resname : str
        Residue name of the ligand to be stripped from the trajectory.
    output_file : str
        Path to save the stripped ligand trajectory file.

    Returns:
    -------
    None
    """
    # Load the trajectory with the topology
    traj = mdtraj.load(trajectory_file, top=topology_file)
    # Select the ligand atoms using MDTraj's atom selection syntax
    ligand_atoms = traj.top.select(f'resname {ligand_resname}')
    # Check if ligand atoms are found
    if len(ligand_atoms) == 0:
        print(f"No atoms found with residue name {ligand_resname}. Please check the residue name.")
        return
    # Strip everything except the ligand
    ligand_traj = traj.atom_slice(ligand_atoms)
    # Save the stripped ligand trajectory
    ligand_traj.save_pdb(output_file)
    log(f'Stripped ligand trajectory saved as {output_file}')
